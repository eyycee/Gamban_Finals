import { useEffect } from 'react' // useState
import './App.css'
import { Box, Button, Icon } from '@mui/material'
import {Headphones, WidthFull, WidthFullOutlined} from '@mui/icons-material'
// import Styledinput from './components/CustomComponents'
import { lightBlue } from '@mui/material/colors'
import { RouterProvider } from 'react-router-dom'
import router from './routes/router'
import { ThemeProvider } from "@emotion/react"
import theme from './Theme'
// import { ToastContainer } from 'react-toastify'
// import 'react-toastify/dist/ReactToastify.min.css'

// CSS SECTION (MAIN PAGE i guess) FRONT

const anyStyle = {
  Width: '100%',
  height: 50,

}

// CSS SECTION (MAIN PAGE i guess) <END>

// FRONT END SECTION <FRONT>

// FUNCTION BUTTON <FRONT>

function App() {
  const [ hidden, setHidden ] = useState(false)

  useEffect(()=>{
    setHidden(false)
  },[])

  useEffect(()=>{
    if(hidden){
      alert('none')
    }
    else{
      alert('none')
    }
  },[hidden])
  
  const handleHide = () => {
    if(hidden){
      setHidden(false)
    }
    else{
      setHidden(true)
    }
  }

// FUNCTION BUTTON <END>

  return (
    <ThemeProvider theme={theme}>
      <main style={{display: "flex", flexDirection: "row", gap: "1rem", alignItems: "center",backgroundColor: "lightBlue",}}>
        <Box sx={anyStyle}>
          <Headphones sx={
            [
              {fontSize: 50}, 
              hidden ? {display: 'none'} : {},
              {color: 'cornflowerblue'},
            ]
          }/>
        </Box>
        <font>
          HoundMusic
        </font>
        <Box mb={1} p={1} sx={{backgroundColor: 'white' }}>
          <Styledinput placeholder='Search'/>
        </Box>
        
        <Box mb={1}>
          <Button variant='contained' onClick={handleHide}>
            {
              hidden ? 'Search' : 'Search'
            }
          </Button>
        </Box>
        <Box mb={1}>
          <Button variant='contained' onClick={handleHide}>
            {
              hidden ? 'Login' : 'Login'
            }
          </Button>
        </Box>
        <Box mb={1}>
          <Button variant='contained' onClick={handleHide}>
            {
              hidden ? 'Register' : 'Register'
            }
          </Button>
        </Box>
        
        <ToastContainer
          position='top-right'
          autoClose={3000}
          hideProgressBar={false}
          closeOnClick
          rtl={false}
          pauseOnHover
        />
          <RouterProvider router={router} />
        
    </main>
    </ThemeProvider>
  )
}  


export default App

// FRONT END SECTION <END>

/* 
  <-- NOTES -->
  css attributes: camelCase
  font size: sx{{fontSize: (number)pt}}
  const anyStyle = global CSS
  useState structure looks like class obj
  function within a parent function must be an arrow function
  anyStyle: Object
  take note: if the page is reloaded, the icon is shown then suddenly disappears
  if the 2nd argument of an useEffect is empty, the code inside will run once page is refreshed/reloaded
  if the 2nd argument of an useEffect isn't empty, useEffect will trigger everytime the variable state changes
*/