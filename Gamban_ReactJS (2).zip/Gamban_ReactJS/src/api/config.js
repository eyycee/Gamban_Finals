export const ENV = "LOCAL"

export const URL = "http://127.0.0.1:8000/"

