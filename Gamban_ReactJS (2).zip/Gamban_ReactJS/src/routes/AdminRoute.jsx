import MainLayout from "../components/layouts/MainLayout"
import Dashboard from "../pages/dashboard"
import Profiles from "../pages/profiles"


const AdminRoute = [
    {
        path: '/',
        element: <MainLayout/>,
        children: [
            {
                path: "",
                element: <Dashboard/>
            },
            {
                path: "/profiles",
                element: <Profiles/>
            }
        ]
    }
]

export default AdminRoute