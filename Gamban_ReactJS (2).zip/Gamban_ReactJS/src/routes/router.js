import { createBrowserRouter } from "react-router-dom";
import AdminRoute from "./AdminRoute";

const router  = createBrowserRouter([...AdminRoute])

export default router