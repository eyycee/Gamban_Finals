import { TextField } from "@mui/material";

export default function Styledinput({type, placeholder}){

    /*
        apply useState() and UseEffect()
    */

    return (
        <TextField variant={type} label={placeholder}/>
    )
}


