import { createTheme } from '@mui/material'

const themeOptions = createTheme({
    palette: {
        primary:{
            main: "lightBlue"
        },
        success:{
            main: "lightGreen"
        },
        secondary:{
            main: "Grey"
        },
        error:{
            main: "red"
        }
    },
    typography:{
        fontFamily: '"Roboto", sans-serif'
    }
})

export default themeOptions