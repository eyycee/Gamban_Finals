import { Box, Typography } from '@mui/material'

function Dashboard(){
    return (
        <Box>
            <Typography variant="h1">
                Welcome!
            </Typography>
        </Box>
    )
}

export default Dashboard